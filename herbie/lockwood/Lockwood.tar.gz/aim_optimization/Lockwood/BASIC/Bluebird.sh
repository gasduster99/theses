#!/bin/csh
./Bluebird

