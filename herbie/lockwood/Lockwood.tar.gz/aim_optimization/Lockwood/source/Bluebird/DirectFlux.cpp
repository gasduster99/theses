//DirectFlux.cpp

#include "Layer.h"

void CSingleLayer::BuildDirectFluxMatrix(){

	//Sift through CRiver, CStage, CSurfaceDrain, etc.
	
  //for each element a0 & a1, can write system of equations

//	potential from all(a0,a1)= specified potential -given potential

}
void CSingleLayer::SolveDirectFluxMatrix(){

}