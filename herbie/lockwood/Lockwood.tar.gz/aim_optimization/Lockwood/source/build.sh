#!/bin/csh

cd Bluebird
cd RxNLib
make
cd ../VectorLib
make
cd ../MatrixLib
make
cd ..
make
cd ..
mkdir executables
mv Bluebird/Bluebird executables/

cd Ostrich
make MW_SER
mv OstrichSerial ../executables/Ostrich
